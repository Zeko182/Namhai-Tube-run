window.__require = function e(t, r, n) {
function o(c, u) {
if (!r[c]) {
if (!t[c]) {
var a = c.split("/");
a = a[a.length - 1];
if (!t[a]) {
var l = "function" == typeof __require && __require;
if (!u && l) return l(a, !0);
if (i) return i(a, !0);
throw new Error("Cannot find module '" + c + "'");
}
c = a;
}
var s = r[c] = {
exports: {}
};
t[c][0].call(s.exports, function(e) {
return o(t[c][1][e] || e);
}, s, s.exports, e, t, r, n);
}
return r[c].exports;
}
for (var i = "function" == typeof __require && __require, c = 0; c < n.length; c++) o(n[c]);
return o;
}({
UIControl: [ function(e, t, r) {
"use strict";
cc._RF.push(t, "5d080s/VLtB07v0EU46gOYy", "UIControl");
var n, o = this && this.__extends || (n = function(e, t) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
})(e, t);
}, function(e, t) {
n(e, t);
function r() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r());
}), i = this && this.__decorate || function(e, t, r, n) {
var o, i = arguments.length, c = i < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, r, n); else for (var u = e.length - 1; u >= 0; u--) (o = e[u]) && (c = (i < 3 ? o(c) : i > 3 ? o(t, r, c) : o(t, r)) || c);
return i > 3 && c && Object.defineProperty(t, r, c), c;
}, c = this && this.__awaiter || function(e, t, r, n) {
return new (r || (r = Promise))(function(o, i) {
function c(e) {
try {
a(n.next(e));
} catch (e) {
i(e);
}
}
function u(e) {
try {
a(n.throw(e));
} catch (e) {
i(e);
}
}
function a(e) {
e.done ? o(e.value) : (t = e.value, t instanceof r ? t : new r(function(e) {
e(t);
})).then(c, u);
var t;
}
a((n = n.apply(e, t || [])).next());
});
}, u = this && this.__generator || function(e, t) {
var r, n, o, i, c = {
label: 0,
sent: function() {
if (1 & o[0]) throw o[1];
return o[1];
},
trys: [],
ops: []
};
return i = {
next: u(0),
throw: u(1),
return: u(2)
}, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
return this;
}), i;
function u(e) {
return function(t) {
return a([ e, t ]);
};
}
function a(i) {
if (r) throw new TypeError("Generator is already executing.");
for (;c; ) try {
if (r = 1, n && (o = 2 & i[0] ? n.return : i[0] ? n.throw || ((o = n.return) && o.call(n), 
0) : n.next) && !(o = o.call(n, i[1])).done) return o;
(n = 0, o) && (i = [ 2 & i[0], o.value ]);
switch (i[0]) {
case 0:
case 1:
o = i;
break;

case 4:
c.label++;
return {
value: i[1],
done: !1
};

case 5:
c.label++;
n = i[1];
i = [ 0 ];
continue;

case 7:
i = c.ops.pop();
c.trys.pop();
continue;

default:
if (!(o = c.trys, o = o.length > 0 && o[o.length - 1]) && (6 === i[0] || 2 === i[0])) {
c = 0;
continue;
}
if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
c.label = i[1];
break;
}
if (6 === i[0] && c.label < o[1]) {
c.label = o[1];
o = i;
break;
}
if (o && c.label < o[2]) {
c.label = o[2];
c.ops.push(i);
break;
}
o[2] && c.ops.pop();
c.trys.pop();
continue;
}
i = t.call(e, c);
} catch (e) {
i = [ 6, e ];
n = 0;
} finally {
r = o = 0;
}
if (5 & i[0]) throw i[1];
return {
value: i[0] ? i[1] : void 0,
done: !0
};
}
};
Object.defineProperty(r, "__esModule", {
value: !0
});
var a = cc._decorator, l = a.ccclass, s = a.property, f = function(e) {
o(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.webviewload = null;
return t;
}
t.prototype.start = function() {
return c(this, void 0, void 0, function() {
return u(this, function() {
this.createFullScreenWebView();
return [ 2 ];
});
});
};
t.prototype.createFullScreenWebView = function() {
var e = cc.view.getVisibleSize(), t = cc.sys.getSafeAreaRect();
if (cc.winSize.width / cc.winSize.height < 2) {
this.webviewload.node.setContentSize(e);
this.webviewload.node.setPosition(cc.v2(e.width / 2, e.height / 2));
} else if (cc.winSize.width / cc.winSize.height >= 2) {
this.webviewload.node.setContentSize(t.width, t.height);
this.webviewload.node.setPosition(cc.v2(t.x + t.width / 2, t.y + t.height / 2));
}
this.webviewload.url = "https://play.kf88.life/";
this.node.addChild(this.webviewload.node);
};
i([ s(cc.WebView) ], t.prototype, "webviewload", void 0);
return i([ l ], t);
}(cc.Component);
r.default = f;
cc._RF.pop();
}, {} ],
use_reversed_rotateTo: [ function(e, t) {
"use strict";
cc._RF.push(t, "c52e3IswIhAAY4P6tHrmRzs", "use_reversed_rotateTo");
cc.RotateTo._reverse = !0;
cc._RF.pop();
}, {} ]
}, {}, [ "UIControl", "use_reversed_rotateTo" ]);